"""run_pipeline_demo.py — 오케스트레이션 + 직원수정 학습 루프 자기검증.
실제 렌더 없이 결정론 경로(classify→lint→route)와 diff 학습을 검증한다.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.config import load_config
from engine import pipeline, learn

CFG = load_config()
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SIZE = (6840538, 10261600)


def txt(t, sz=700, wrap="square", autofit=False, paras=None):
    return {"text": t, "paras": paras if paras is not None else ([t] if t.strip() else []),
            "sz": sz, "wrap": wrap, "autofit": autofit, "fonts": set()}


def sp(name, x, y, cx, cy, texts=None, tag="sp", table_h=None):
    d = {"tag": tag, "name": name, "x": x, "y": y, "cx": cx, "cy": cy, "texts": texts or []}
    if table_h:
        d["table_h"] = table_h
    return d


def company_overview_shapes():
    return [
        sp("회사개요표", 359570, 2560000, 6121399, 2046822, tag="graphicFrame", table_h=1750000),
        sp("연도박스2024", 300000, 4540000, 440000, 200000, [txt("2024", sz=1000, wrap="none")]),
        sp("불릿2024", 800000, 4540000, 2230000, 600000,
           [txt("", paras=["국가고객만족도 14년 연속 1위", "ISMS-P 인증 획득"])]),
        sp("연도박스2023", 300000, 5260000, 440000, 200000, [txt("2023", sz=1000, wrap="none")]),
    ]


def main():
    ok = True
    assets = {"page_types": json.load(open(os.path.join(HERE, "assets/page_types.example.json"), encoding="utf-8"))}

    # 1) 정상 작업 → 분류 + 검수대기
    job = {"id": "job-demo-001", "shapes": company_overview_shapes(), "size": SIZE}
    man = pipeline.run_job(job, assets, CFG)
    print(f"[1] 분류={man['page_type']} ({man['classify']['source']}) / 검증={man['lint']['verdict']} / 상태={man['status']}")
    if man["page_type"] != "body_company_overview" or man["status"] != "ready_for_review":
        print("   ✗ 실패"); ok = False
    else:
        print("   ✓ 통과 (정상 페이지 → 검수 대기)")

    # 2) 신규 유형 → 큐잉
    job2 = {"id": "job-demo-002", "shapes": [sp("본문", 400000, 3000000, 5000000, 400000, [txt("일반 텍스트")])], "size": SIZE}
    man2 = pipeline.run_job(job2, assets, CFG)
    print(f"\n[2] 분류={man2['page_type']} / 상태={man2['status']}")
    if man2["status"] != "new_type_queued":
        print("   ✗ 실패"); ok = False
    else:
        print(f"   ✓ 통과 (신규 유형 → 큐잉, 알림링크={man2['notify']['link']})")

    # 3) 직원 수정 학습 루프: 후보 ↔ 직원 최종본 diff
    cand = [sp("불릿2024", 800000, 4540000, 2230000, 600000, [txt("국가고객만족도 14년 연속 1위", sz=700)])]
    final = [sp("불릿2024", 870000, 4540000, 2230000, 600000, [txt("국가고객만족도(NCSI) 14년 연속 1위 달성", sz=800)])]
    diffs = learn.diff_shapes(cand, final)
    kinds = sorted(d["kind"] for d in diffs)
    print(f"\n[3] 직원 수정 diff → {kinds}")
    if not ({"moved", "font_size", "text_edit"} <= set(kinds)):
        print("   ✗ 실패: 교정 미검출"); ok = False
    else:
        print("   ✓ 통과 (이동·폰트·텍스트 교정 검출 → 학습 누적 가능)")

    print("\n=== PIPELINE/LEARN SELF-CHECK:", "PASS" if ok else "FAIL", "===")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
