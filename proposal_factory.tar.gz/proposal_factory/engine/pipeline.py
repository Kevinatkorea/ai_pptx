"""pipeline.py — 오케스트레이터: ingest→classify→transform→capture→lint→route.
보안망(AI 불가)에서도 동작: gateway=None 이면 결정론 경로만 사용.
"""
import time

from . import classify, linter, notify


def route(verdict, findings, cfg):
    """검증 결과 → 다음 행동. 구조 결함=사람 승인, 그 외=검수 대기."""
    fails = [c for sev, c, _, _ in findings if sev == "fail"]
    autofixable = set(cfg["autofix"].get("autofix_fail_codes", []))
    if fails and not set(fails).issubset(autofixable):
        return "needs_human_approval"
    if fails:
        return "autofix_then_recheck"
    return "ready_for_review"


def run_job(job, assets, cfg, gateway=None, capture_fn=None):
    """job: {id, source_slots, shapes(or pptx)}. 반환: job manifest."""
    man = {"id": job["id"], "ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "steps": []}

    ptype, conf, src = classify.classify(job["shapes"], assets["page_types"], gateway)
    man["page_type"] = ptype
    man["classify"] = {"confidence": conf, "source": src}
    if ptype == "unknown":
        man["status"] = "new_type_queued"  # 신규 유형 → 사람/AI 레시피 작성 대기
        man["notify"] = notify.notify_review(job["id"], cfg, "신규 유형 검토")
        return man

    # transform → capture 는 실제 파일 경로가 있을 때 수행(여기선 shapes 직접 사용)
    shapes = job["shapes"]
    size = job.get("size", (6840538, 10261600))
    findings = linter.lint(shapes, size[0], size[1], cfg)
    verdict, nf, nw, text = linter.report(findings)
    man["lint"] = {"verdict": verdict, "fails": nf, "warns": nw, "findings": findings}
    man["status"] = route(verdict, findings, cfg)
    if man["status"] != "ready_for_review":
        man["notify"] = notify.notify_review(job["id"], cfg, "구조 수정 승인 필요")
    return man
