"""pptx_io.py — 검증된 PPTX 도구 래퍼(unpack/pack/clean/render).
Mac 배포 시 scripts/ 에 vendoring(동봉)하고 PPTX_TOOLS 경로만 바꾸면 됨.
"""
import os
import subprocess

PPTX_TOOLS = os.environ.get("PPTX_TOOLS", "/mnt/skills/public/pptx")


def _py(script, *args):
    subprocess.run(["python3", os.path.join(PPTX_TOOLS, script), *args], check=True)


def unpack(pptx, outdir):
    _py("ooxml/scripts/unpack.py", pptx, outdir)


def pack(srcdir, out, original):
    _py("ooxml/scripts/pack.py", srcdir, out, "--original", original)


def clean(srcdir):
    _py("ooxml/scripts/clean.py", srcdir)


def render_pdf(pptx, outdir, soffice="soffice"):
    subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", outdir, pptx], check=True)


def pdf_to_png(pdf, prefix, dpi=140):
    subprocess.run(["pdftoppm", "-jpeg", "-r", str(dpi), pdf, prefix], check=True)
