"""ai.py — 3단 지능 게이트웨이 + 월 예산 상한.
deterministic(무료) → local LLM(Ollama, 무료) → Claude API(소액, 상한 내).
보안망: config.ai.cloud.enabled=false 로 두면 1~2단만 사용(토큰 0).
"""
import json
import os
import time

_LOG = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")


class AIGateway:
    def __init__(self, cfg):
        self.cfg = cfg["ai"]
        os.makedirs(_LOG, exist_ok=True)
        self.spend_path = os.path.join(_LOG, "ai_spend.json")

    def _spend(self):
        try:
            return json.load(open(self.spend_path, encoding="utf-8"))
        except Exception:
            return {}

    def remaining_budget(self):
        m = time.strftime("%Y-%m")
        used = self._spend().get(m, 0.0)
        return self.cfg["monthly_budget_usd"] - used

    def _record(self, usd):
        m = time.strftime("%Y-%m")
        s = self._spend()
        s[m] = round(s.get(m, 0.0) + usd, 4)
        json.dump(s, open(self.spend_path, "w", encoding="utf-8"))

    def can_use_cloud(self):
        return self.cfg["cloud"]["enabled"] and self.remaining_budget() > 0

    # --- 연동 지점(스텁) -------------------------------------------------
    def local_classify(self, prompt):
        """Ollama 호출 지점. 예: POST http://localhost:11434/api/generate"""
        raise NotImplementedError("Ollama 로컬 LLM 연동 지점 (qwen2.5/EXAONE)")

    def cloud_classify(self, prompt):
        if not self.can_use_cloud():
            return None  # 예산 초과 → 호출자에서 로컬/사람 폴백
        raise NotImplementedError("Claude Haiku 분류 연동 지점 + self._record(비용)")

    def author_recipe(self, prompt):
        if not self.can_use_cloud():
            return None
        raise NotImplementedError("Claude Opus 레시피 작성 연동 지점 + self._record(비용)")
