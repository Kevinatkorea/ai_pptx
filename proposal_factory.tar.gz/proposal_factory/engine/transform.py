"""transform.py — 레시피 적용. Phase-1에서 검증한 4대 변환 연산을 흡수하는 지점.
  (1) text_inject   : 본문 텍스트 페이지 → 슬롯에 네이티브 텍스트 주입
  (2) table_rebuild : 표 데이터 → 템플릿 표 스타일로 재생성
  (3) image_reuse   : 원본 이미지(인증서 등) r:embed 리맵 후 재배치
  (4) shape_rebuild : 타임라인/연도배지 등 도형을 균일 간격으로 재구성
각 연산은 pptx_io 로 unpack→편집(문자열 OOXML)→clean→pack 한다.
"""


def apply(recipe, source_slots, template_dir, out_pptx, cfg):
    """recipe.ops 순서대로 변환 적용. 반환: 생성된 후보 pptx 경로."""
    raise NotImplementedError(
        "Phase-1 검증 로직 이식 지점: text_inject/table_rebuild/image_reuse/shape_rebuild")
