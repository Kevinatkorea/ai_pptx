"""watch_inbox.py — /inbox 폴더 감시(폴링) + 수동 실행 진입점.
Mac: launchd 로 상시 가동. 새 파일 감지 → pipeline.run_job → /review 또는 메일 알림.
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.config import load_config

CFG = load_config()
INBOX = os.path.join(CFG["nas"]["mount"], "inbox")
POLL = 5


def process(path):
    print(f"[watch] 처리 시작: {path}")
    # TODO: capture.capture → classify → transform → lint → route (pipeline.run_job)


def loop():
    seen = set()
    print(f"[watch] 감시 시작: {INBOX}")
    while True:
        try:
            for f in os.listdir(INBOX):
                p = os.path.join(INBOX, f)
                if p not in seen and os.path.isfile(p):
                    seen.add(p); process(p)
        except FileNotFoundError:
            pass
        time.sleep(POLL)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        process(sys.argv[1])
    else:
        loop()
